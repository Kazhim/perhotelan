<?php

namespace App\Models;

use Facade\Ignition\QureyRecorder\Query;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class fasilitas extends Model
{
    use HasFactory;

    protected $fillable = [
        'nama_fasilitas',
        'harga',
    ];

    public function scopeStoreFasilitas($query, $request)
    {
        $status = $query->create([
            'nama_fasilitas' => $request->nama_fasilitas,
            'harga' => $request->harga,

        ]);

        if(!$status) return false;

        return true;
    }

    public function scopeUpdateFasilitas($query, $request)
    {
        $status = $query->where('id', $request->id)->update([
            'nama_fasilitas'    => $request->nama_fasilitas,
            'harga' => $request->harga,
           
        ]);

        if(!$status) return false;

        return true;
    }
}
