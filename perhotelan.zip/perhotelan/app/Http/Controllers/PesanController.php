<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\tamu;


class PesanController extends Controller
{
    public function pesan()
    {
        return view('fronhend.edit-tamu');
    }
    public function storeTamu(Request $request)
    {
       $status = tamu::storeTamu($request);
       if ($status)return redirect('/edit-tamu');
       else return redirect('/edit-tamu');
   
       }
    public function sukses()
    {
        return view('fronhend.order-sukses');
    }
    
}
