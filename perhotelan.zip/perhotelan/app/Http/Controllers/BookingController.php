<?php

namespace App\Http\Controllers;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\tamu;

class BookingController extends Controller
{
    public function tampilanBooking()
  {
    return view('fronhend.booking');
  }

  public function tampilandatabooking()
  {
    $data = [];
    $tamu = Tamu::get();
    foreach ($tamu as $item) {
      $data[] = [
          $item->id,
          $item->nama_tamu,
          $item->nama_kamar,
          $item->fasilitas,
          '<a href="/edit/'.$item->id.'" class="btn btn-primary">Edit</a>, <a href="/delete/'.$item->id.'" class="btn btn-danger">Delete</a>'
      
      ];
  }

    return [
      'data' => $data,
    ];
  }
}
