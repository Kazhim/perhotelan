<?php

namespace App\Http\Controllers;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\tamu;

class TamuController extends Controller
{
     public function tamu()
    {
        return view('fronhend.tamu');
    }
    public function create()
    {
        return view('fronhend.form-inputtamu');
    }

   public function storetamu(Request $request)
 {
    $status = tamu::storetamu($request);
    if ($status)return redirect('/tamu');
    else return redirect('/form-inputtamu');

    }
    public function datatabletamu()
    {
      $data = [];
      $tamu = tamu::get();
      foreach ($tamu as $item) {
        $data[] = [
            $item->id,
            $item->nama_tamu,
            $item->nama_alamat,
            $item->no_telpon,
            '<a href="/edit/'.$item->id.'" class="btn btn-primary">Edit</a>, <a href="/delete/'.$item->id.'" class="btn btn-danger">Delete</a>'
        
        ];
    }

      return [
        'data' => $data,
      ];
    }
    public function destroy($id)
    {
      $delete = tamu::where('id',$id)->delete();

      if($delete) return redirect('/tampilan');
      else return 'gagal delete data';
    }
    public function edit($id)
    {
     $data['tamus'] = tamu::find($id);
     return view('fronhend.edit', $data);
  }
  public function update(Request $request)
  {
    $update = tamu::updateTamu($request);
    if ($update) return redirect('/tampilan');
    else return 'gagal update data';
  }
 


 

  public function datatamusidebar()
  {
    return view('fronhend.datatamu');
  }
}
