

<?php $__env->startSection('content'); ?>
  <div class="card">
    <div class="card-body">
      <form method="POST" action="/store-tamu">
        <?php echo csrf_field(); ?>
        <div class="mb-3">
          <label for="exampleInputEmail1">Nama Tamu</label>
          <input type="text" class="form-control" id="exampleInputEmail1" name="nama_tamu" placeholder="Masukan Nama Kamar" aria-describedby="emailHelp">
        </div>
        <div class="mb-3">
          <label for="exampleInputEmail1">Alamat</label>
          <input type="text" class="form-control" id="exampleInputEmail1" name="nama_alamat" placeholder="Masukan Nama Alamat" aria-describedby="emailHelp">
        </div>
        <div class="mb-3">
          <label for="exampleInputEmail1">No Telpon</label>
          <input type="text" class="form-control" id="exampleInputEmail1" name="no_telpon" placeholder="Masukan Nomor Telpon" aria-describedby="emailHelp">
        </div> 
        <button type="submit" class="btn btn-primary float-end">Tambah</button>
      </form>
    </div>
  </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\perhotelan\resources\views/fronhend/form-input.blade.php ENDPATH**/ ?>