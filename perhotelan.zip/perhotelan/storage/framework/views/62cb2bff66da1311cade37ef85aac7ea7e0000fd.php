

<?php $__env->startSection('content'); ?>
  <div class="card">
    <div class="card-body">
      <form method="POST" action="update">
        <?php echo csrf_field(); ?>
        <div class="card">
    <div class="card-body">
      <form method="POST" action="/store-tamu">
        <?php echo csrf_field(); ?>
        <div class="mb-3">
          <label type="hidden" for="exampleInputEmail1">Nama Tamu</label>
          <input type="text" class="form-control" id="exampleInputEmail1" name="nama_tamu" placeholder="No Kamar" aria-describedby="emailHelp">
        </div>
        <div class="mb-3">
          <label for="exampleInputEmail1">Jenis Kelamin</label>
          <select class="form-control"name="jenis_kelamin">
          <option value="Laki-Laki">Laki-Laki</option>
          <option value="Perempuan">Perempuan</option>
</select>
        </div>
        <div class="mb-3">
          <label for="exampleInputEmail1">Nama Kamar</label>
          <input type="text" class="form-control" id="exampleInputEmail1" name="nama_kamar" placeholder="Nama Kamar" aria-describedby="emailHelp">
        </div>
        <div class="mb-3">
          <label for="exampleInputEmail1">Fasilitas</label>
          <input type="text" class="form-control" id="exampleInputEmail1" name="fasilitas" placeholder="No Kamar" aria-describedby="emailHelp">
        </div>
        <div class="mb-3">
          <label for="exampleInputEmail1">No Telpon</label>
          <input type="text" class="form-control" id="exampleInputEmail1" name="no_telpon" placeholder="No Kamar" aria-describedby="emailHelp">
        </div> <div class="mb-3">
          <label for="exampleInputEmail1">Email</label>
          <input type="text" class="form-control" id="exampleInputEmail1" name="email" placeholder="No Kamar" aria-describedby="emailHelp">
        </div>
        <button type="submit" class="btn btn-primary float-end">Update</button>
      </form>
    </div>
  </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\perhotelan\resources\views/fronhend/edit.blade.php ENDPATH**/ ?>