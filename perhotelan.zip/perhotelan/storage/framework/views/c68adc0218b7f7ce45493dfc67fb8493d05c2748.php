

<?php $__env->startSection('content'); ?>
<center> <h2>HOME</h2> </center>
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.0.0/dist/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
<div class="card text-white bg-dark mb-3" style="max-width: 18rem;">
  <div class="card-header">JUMLAH TAMU</div>
  <div class="card-body">
    <h5 class="card-header"><?php echo e($users); ?></h5>
  </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\perhotelan\resources\views/fronhend/dashbord.blade.php ENDPATH**/ ?>